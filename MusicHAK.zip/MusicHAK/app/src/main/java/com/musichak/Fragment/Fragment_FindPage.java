package com.musichak.Fragment;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.RecyclerView;

import com.musichak.R;

public class Fragment_FindPage extends Fragment {

    View view;
    Toolbar toolbar;
    RecyclerView recyclerViewSearchBaiHat;
    TextView txtNoData;
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.fragment_findpage,container,false);
        toolbar = view.findViewById(R.id.toolbarSearchBaiHat);
        recyclerViewSearchBaiHat = view.findViewById(R.id.recyclerviewSearchBaiHat);
        txtNoData = view.findViewById(R.id.textviewNodata);
        ((AppCompatActivity)getActivity()).setSupportActionBar(toolbar);
        toolbar.setTitle("");

        return view;
    }
}
